python train_one_hot.py --batch_size 8 --model pointnet2_part_seg_msg_one_hot --log_dir log_msg_one_hot --gpu 0 --max_epoch 201 > log_msg_one_hot.txt 2>&1 &
